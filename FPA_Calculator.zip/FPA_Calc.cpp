//
//  FPA_Calc.cpp
//  FPA_Analysis
//
//  Created by Pacifico Catapano on 15/10/2020.
//

#include "FPA_Calc.hpp"
#include <iostream> 
#include <string.h>
using namespace std;
   
float ufp_calc(int fp[5]){
    float ufp = 0;
    int fattori[5][3] = {
        { 3, 4, 6 },
        { 4, 5, 7 },
        { 3, 4, 6 },
        { 7, 10, 15 },
        { 5, 7, 10 },
    };

    int weight = 0;
    cout<<"Assegna un peso ad ogni funzione. \n 0. Semplice 1. Medio 2. Alto"<<endl;
    for (int j=0; j<5;++j){
        for (int i = 0; i < fp[j]; ++i ){
            cout<<endl;
            cin>>weight;
            while (weight != 0 && weight != 1 && weight != 2) {
                cout<<"Peso errato. Reinserisci peso"<<endl;
                cin>>weight;
            }
            ufp += fattori[j][weight];
        }
    }
    return ufp;
}

float caf_calc(){
    float caf = 0;
    //14 fattori
    string aspects[14] = {
        "Frequenza delle transazioni ",
        "Comunicazione dati ",
        "Elaborazioni distribuite ",
        "Prestazioni ",
        "Utilizzo intensivo della configurazione ",
        "Inserimento dati interattivo ",
        "Efficienza per l'utente finale ",
        "Aggiornamento interattivo ",
        "Complessità elaborativa",
        "Facilità gestione operativa (usabilità) ",
        "Riusabilità ",
        "Facilità di installazione ",
        "Molteplicità di siti ",
        "Facilità nella modifica  "
    };
   
    int rate_scale = 0;
    cout<<"Inserisci un valore tra 0. Ininfluente 1. Incidenza marginale 2. Incidenza moderata 3. Incidenza media 4. Incidenza significativa 5. Incidenza essenziale";
    for (int i=0;i<14;++i){
        cout<<aspects[i];
        cin>>rate_scale;
        while (rate_scale != 0 && rate_scale != 1 && rate_scale != 2 && rate_scale != 3 && rate_scale != 4 && rate_scale != 5 ) {
            cout<<"Inserimento non corretto. Riprova"<<endl;
            cin>>rate_scale;
        }
        caf+= rate_scale+1;
    }
    return caf;
}


float final_calc (float ufp, float caf){
    float result = 0;
    result = (caf*0.01)+0.65;
    result = result*ufp;
    return result;
}
   
