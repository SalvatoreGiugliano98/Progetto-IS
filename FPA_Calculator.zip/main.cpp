//
//  main.cpp
//  FPA_Analysis
//
//  Created by Pacifico Catapano on 15/10/2020.
//

#include <iostream>
#include "FPA_Calc.hpp"
using namespace std;

int main()
{
    float result = 0;
    //BLOCCO REGISTRAZIONI FUNZIONI DATI E TRASFERIMENTO
    int fp[5];
    cout << "Inserisci numero di ILF \n" ;
    cin >> fp[0];
    cout << "Inserisci numero di ELF \n" ;
    cin >> fp[1];
    cout << "Inserisci numero di EI \n" ;
    cin >> fp[2];
    cout << "Inserisci numero di EO \n" ;
    cin >> fp[3];
    cout << "Inserisci numero di EN \n" ;
    cin >> fp[4];
    // FINE BLOCCO
    
    float ufp = ufp_calc(fp);
    cout<<"UFP: "<<ufp<<endl;
  
    float caf = caf_calc();
    cout<<"CAF: "<<caf<<endl;
    
    result = final_calc(ufp,caf);
    cout<<"Costo stimato software: "<<result<<endl;
    return 0;
}
