//
//  FPA_Calc.hpp
//  FPA_Analysis
//
//  Created by Pacifico Catapano on 15/10/2020.
//

#ifndef FPA_Calc_hpp
#define FPA_Calc_hpp

#include <stdio.h>

float ufp_calc(int fp[5]);
float caf_calc();
float final_calc(float ufp, float caf);
#endif /* FPA_Calc_hpp */
